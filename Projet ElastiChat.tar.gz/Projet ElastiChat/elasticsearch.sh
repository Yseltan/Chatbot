#!/bin/sh
echo "Connection à Elasticsearch"
chmod u+xrw ./elasticsearch-5.1.2/bin/elasticsearch
./elasticsearch-5.1.2/bin/elasticsearch
